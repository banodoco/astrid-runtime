"""Read the unchanged CPU probe's two attempts through the public Runtime API."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import runtime_protocol
from runtime_protocol.daemon import RuntimeDaemon
from astrid_runtime_client import WorkspaceClient


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--observations", type=Path, required=True)
    parser.add_argument("--realm", type=Path, required=True)
    parser.add_argument("--support-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    observations = json.loads(args.observations.read_text())
    assert observations["probe_sha256"] == "671648e5b9287ead292f2ded239d0af64fd64e6aeaa0e4a541bfcb59192a1e22"
    assert observations["observations"]["retry_succeeded"] is True
    attempts = {row["id"]: row for row in observations["attempts"]}
    expected = {row["association_id"]: row for row in observations["log_associations"]}
    assert len(attempts) == 2 and len(expected) == 4
    daemon = RuntimeDaemon(args.realm, support_root=args.support_root).start()
    try:
        client = WorkspaceClient(daemon.endpoint, daemon.token)
        task = client.get_task(observations["task_id"])
        assert task.state == "succeeded"
        rows, cursor = client.list_managed_outputs(task.task_id)
        assert cursor is None
        logs = [row for row in rows if row.role == "log"]
        assert {row.association_id for row in logs} == set(expected)
        reads = []
        for row in logs:
            assert client.get_managed_output(row.association_id) == row
            original = expected[row.association_id]
            attempt = attempts[row.attempt_id]
            assert row.task_id == task.task_id == attempt["task_id"]
            assert row.attempt_id == original["attempt_id"]
            assert row.provenance == json.loads(original["provenance_json"])
            assert row.provenance["attempt_id"] == attempt["id"]
            assert row.provenance["fence"] == attempt["fence"]
            assert row.provenance["runtime_epoch"] == attempt["runtime_epoch"]
            assert row.provenance["executor_id"] == attempt["executor_id"]
            assert row.provenance["capability_id"] == "ls6_general_retry.echo"
            assert row.output_port == "logs" and row.durability == "durable"
            data = client.get_object(row.object_id).data
            wanted = {"job.stdout": b"ordinary retry stdout\n", "job.stderr": b"ordinary retry stderr\n"}
            assert data == wanted[row.variant_key]
            assert row.object_id == "sha256:" + hashlib.sha256(data).hexdigest()
            assert row.size == len(data)
            reads.append({"association": asdict(row), "data_utf8": data.decode(),
                          "bytes_sha256": hashlib.sha256(data).hexdigest()})
        assert {(row.attempt_id, row.variant_key) for row in logs} == {
            (attempt, stream) for attempt in attempts for stream in ("job.stdout", "job.stderr")
        }
        report = {"result": "PASS", "task_id": task.task_id, "state": task.state,
                  "runtime_module": runtime_protocol.__file__, "read_after_restart": True,
                  "original_probe_sha256": observations["probe_sha256"], "reads": reads}
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"result": "PASS", "attempts": 2, "log_reads": len(reads),
                          "read_after_restart": True, "output": str(args.output)}))
    finally:
        daemon.stop()


if __name__ == "__main__":
    main()
