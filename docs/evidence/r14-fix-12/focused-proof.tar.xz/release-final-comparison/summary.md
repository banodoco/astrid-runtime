| Side | Tests run |
|---|---|
| release-base | 80 |
| candidate | 80 |

| Bucket | Count |
|---|---|
| regression | 0 |
| no-baseline | 0 |
| preexisting | 0 |
| fixed | 4 |
| missing | 0 |
