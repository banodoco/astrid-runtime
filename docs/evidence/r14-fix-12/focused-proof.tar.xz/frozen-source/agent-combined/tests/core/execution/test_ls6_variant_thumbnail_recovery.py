"""Deferred primary and preserved-edit previews survive a host/Runtime restart."""
from __future__ import annotations

import hashlib
import io

import pytest
from PIL import Image

from astrid.core.execution.generic_host import GenericPackHost, RuntimeProtocolClient
from astrid_runtime_client import WorkspaceClient
from tests.core.execution.test_ls6_image_thumbnail_readiness import (
    MAIN, ROOT, THUMBNAIL, _image_pack, _without_ffmpeg,
)


pytestmark = pytest.mark.integration


def _image(color):
    stream = io.BytesIO()
    Image.new("RGB", (40, 30), color).save(stream, format="PNG")
    return stream.getvalue()


def _host(pack, matrix, root, daemon, *, previews):
    host = GenericPackHost(
        pack_roots=[pack, *([ROOT / "astrid/packs/generation"] if previews else [])],
        capability_matrix=matrix, client=RuntimeProtocolClient(daemon.endpoint, daemon.worker_token),
        executor_id="astrid-pack-host", attempt_base=root / "attempts",
    )
    host.register()
    assert host.capabilities[MAIN].ready
    assert (THUMBNAIL in host.capabilities) is previews
    if previews:
        assert host.capabilities[THUMBNAIL].ready
    return host


def _admit(api, host, project_id, data, *, key, effect, source=None):
    object_id = api.ingest_project_object(project_id, data, media_type="image/png",
        filename="source.png", idempotency_key=f"{key}-source")["digest"]
    assert object_id == "sha256:" + hashlib.sha256(data).hexdigest()
    inputs = [object_id, *([source] if source else [])]
    return api.admit_task(
        capability_id=MAIN, capability_digest=host.capabilities[MAIN].capability_digest,
        project_id=project_id, input_object_ids=inputs, idempotency_key=key,
        spec={"inputs": {"source": {"object_id": object_id, "digest": object_id,
            "sha256": object_id.removeprefix("sha256:"), "size": len(data),
            "filename": "source.png", "media_type": "image/png"}}},
        settlement_effect=effect,
        storage_estimate={"scratch_bytes": 2097152, "output_bytes": 524288},
    )


def test_primary_and_preserved_edit_previews_recover_as_ordinary_tasks(
    tmp_path, monkeypatch, real_runtime,
):
    _without_ffmpeg(tmp_path, monkeypatch)
    pack, matrix = _image_pack(tmp_path)
    daemon = real_runtime()
    api = WorkspaceClient(daemon.endpoint, daemon.token)
    # This host can finish the creative actions before the preview capability
    # is installed. Runtime, not this host, owns the durable preview proposals.
    host = _host(pack, matrix, tmp_path, daemon, previews=False)
    original, edited = _image((25, 60, 95)), _image((160, 70, 30))
    original_id = "sha256:" + hashlib.sha256(original).hexdigest()
    edited_id = "sha256:" + hashlib.sha256(edited).hexdigest()
    try:
        project = api.create_project("Variant preview recovery", idempotency_key="variants-project")
        main = _admit(api, host, project.project_id, original, key="original", effect={
            "effect_type": "generation.create_with_variant", "target_id": project.project_id,
            "payload": {"generation_type": "image", "metadata": {"shot_id": "preserved"},
                "variant_type": "original", "output_name": "image", "output_ordinal": 0,
                "primary_policy": "preserve"},
        })
        assert [row.state for row in host.run(once=True)] == ["succeeded"]
        main = api.get_task(main.task_id)
        main_intent, = main.result["thumbnail_intents"]
        assert main_intent["source_object_id"] == original_id
        generations, cursor = api.list_generations(project.project_id)
        assert cursor is None and len(generations) == 1
        generation = generations[0]
        variants, cursor = api.list_variants(generation.generation_id)
        assert cursor is None and len(variants) == 1
        primary = variants[0]
        assert primary.object_id == original_id and primary.thumbnail is None
        edit = _admit(api, host, project.project_id, edited, key="edit", source=original_id, effect={
            "effect_type": "generation.variant.append", "target_id": generation.generation_id,
            "expected_version": generation.version,
            "payload": {"source_variant_id": primary.variant_id, "source_object_id": original_id,
                "variant_type": "edit", "output_name": "image", "output_ordinal": 0,
                "primary_policy": "preserve"},
        })
        assert [row.state for row in host.run(once=True)] == ["succeeded"]
        edit = api.get_task(edit.task_id)
        edit_intent, = edit.result.get("thumbnail_intents", [])
        assert edit_intent["source_object_id"] == edited_id
        assert edit_intent["generation_id"] == generation.generation_id
        assert edit_intent["intent_id"] != main_intent["intent_id"]
        before = api.get_generation(generation.generation_id)
        assert before.version == generation.version + 1
        assert before.metadata["shot_id"] == "preserved" and "thumbnail" not in before.metadata
        variants, cursor = api.list_variants(generation.generation_id)
        assert cursor is None and {v.object_id for v in variants} == {original_id, edited_id}
        assert all(v.thumbnail is None for v in variants)
        tasks, cursor = api.list_project_tasks(project.project_id)
        assert cursor is None and len(tasks) == 2 and all(task.state == "succeeded" for task in tasks)

        # Persist both intents, restart the same realm, then install/reconcile
        # the ordinary shipped preview action. No creative task is repeated.
        host.shutdown()
        daemon.stop()
        daemon = real_runtime()
        api = WorkspaceClient(daemon.endpoint, daemon.token)
        host = _host(pack, matrix, tmp_path, daemon, previews=True)
        pending = host.client.pending_thumbnail_intents(executor_id=host.executor_id)["items"]
        assert {item["intent_id"] for item in pending} == {
            main_intent["intent_id"], edit_intent["intent_id"],
        }
        assert [row.state for row in host.run(once=True)] == ["succeeded"]
        assert [row.state for row in host.run(once=True)] == ["succeeded"]
        after = api.get_generation(generation.generation_id)
        assert after.version == before.version
        assert after.metadata["shot_id"] == "preserved"
        assert after.metadata["thumbnail"]["source_object_id"] == original_id
        variants, cursor = api.list_variants(generation.generation_id)
        assert cursor is None and len(variants) == 2
        for variant in variants:
            assert variant.thumbnail is not None and variant.viewed_at is None
            assert variant.thumbnail["source_object_id"] == variant.object_id
            assert variant.thumbnail["recipe_version"] == 1
            thumbnail = api.get_object(variant.thumbnail["object_id"]).data
            assert variant.thumbnail["object_id"] == "sha256:" + hashlib.sha256(thumbnail).hexdigest()
            with Image.open(io.BytesIO(thumbnail)) as image:
                image.load()
                assert image.format == "JPEG" and image.size == (40, 30)
            if variant.variant_id == primary.variant_id:
                assert variant.thumbnail == after.metadata["thumbnail"]
        tasks, cursor = api.list_project_tasks(project.project_id)
        assert cursor is None and len(tasks) == 4
        previews = [task for task in tasks if task.capability_id == THUMBNAIL]
        assert len(previews) == 2 and all(task.state == "succeeded" for task in previews)
        assert {tuple(task.input_object_ids) for task in previews} == {(original_id,), (edited_id,)}
        for creative in (main, edit):
            assert api.get_task(creative.task_id).attempt_id == creative.attempt_id
        assert api.get_object(original_id).data == original
        assert api.get_object(edited_id).data == edited
        assert host.run(once=True) == []
        assert host.client.pending_thumbnail_intents(executor_id=host.executor_id)["items"] == []
    finally:
        host.shutdown()
        daemon.stop()
