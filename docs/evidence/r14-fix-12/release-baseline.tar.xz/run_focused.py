"""Record a scoped pytest run without changing its tests or product inputs."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent


def identity(path):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(path), *args])
    names = git("ls-files", "-m", "-o", "--exclude-standard", "-z").decode().split("\0")
    return {
        "root": str(path), "commit": git("rev-parse", "HEAD").decode().strip(),
        "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git("status", "--short").decode().splitlines(),
        "tracked_diff_sha256": hashlib.sha256(git("diff", "HEAD", "--binary")).hexdigest(),
        "worktree_files": {name: hashlib.sha256((path / name).read_bytes()).hexdigest()
                           for name in sorted(set(names)) if name and (path / name).is_file()},
    }


parser = argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("--cwd", required=True)
parser.add_argument("--repo", action="append", default=[])
parser.add_argument("--env", action="append", default=[])
parser.add_argument("pytest_args", nargs=argparse.REMAINDER)
args = parser.parse_args()
prefix = ROOT / "proof" / args.label
repos = [Path(p).resolve() for p in (args.repo or [args.cwd])]
updates = dict(item.split("=", 1) for item in args.env)
env = dict(os.environ, **updates)
selection = args.pytest_args[1:] if args.pytest_args[:1] == ["--"] else args.pytest_args
command = [str(ROOT / "test-env/bin/python"), "-m", "pytest", "-q", "-rA", *selection,
           f"--basetemp={prefix}-tmp", f"--junitxml={prefix}.xml"]
result = {"command": command, "cwd": args.cwd, "environment": updates,
          "started_utc": datetime.now(timezone.utc).isoformat(),
          "before": [identity(repo) for repo in repos]}
Path(str(prefix) + ".before.json").write_text(json.dumps(result, indent=2) + "\n")
with Path(str(prefix) + ".log").open("w") as out:
    completed = subprocess.run(command, cwd=args.cwd, env=env, stdout=out, stderr=subprocess.STDOUT)
result.update(exit_code=completed.returncode, finished_utc=datetime.now(timezone.utc).isoformat(),
              after=[identity(repo) for repo in repos])
result["inputs_unchanged"] = result["before"] == result["after"]
result["artifacts"] = {suffix: hashlib.sha256(Path(str(prefix) + suffix).read_bytes()).hexdigest()
                       for suffix in (".log", ".xml") if Path(str(prefix) + suffix).exists()}
Path(str(prefix) + ".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"label": args.label, "exit_code": completed.returncode,
                  "inputs_unchanged": result["inputs_unchanged"], "log": str(prefix) + ".log"}))
sys.exit(completed.returncode)
