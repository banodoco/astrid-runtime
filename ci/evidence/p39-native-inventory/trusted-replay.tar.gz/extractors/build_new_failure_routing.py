from pathlib import Path
import json, gzip, hashlib, re

root=Path('/workspace/scratch/84d992308703')
repo=root/'astrid-runtime'
old=Path('/workspace/scratch/984232aa1788/evidence-research')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((root/'evidence/historical-failure-map.json').read_text())
g2=json.loads(gzip.decompress((old/'g2-report.json.gz').read_bytes()))
seed=json.loads((repo/'ci/evidence/p39-k2-k3/seed-summary.json').read_text())
manifest=json.loads((repo/'ci/required-checks.json').read_text())
artifacts=json.loads((root/'evidence/source/artifacts.json').read_text())
old_for_lane={s['lane']:s for s in seed['source_artifacts']}
new=[r for r in d['failures'] if r['g2_relationship']=='unmatched_or_ambiguous_historical_failure']
failed={(r['lane'],r['native_id']) for r in d['failures']}
recovering=[]
for job in g2['jobs']:
    if job['repo']=='astrid-runtime':
        lane=job['workflow']+'/'+job['name']
        recovering.extend((lane,r) for r in job.get('rows',[]) if (lane,r['nodeid']) not in failed)
needed={(r['lane'],r['native_id']) for r in new}|{(lane,r['nodeid']) for lane,r in recovering}
current={}
for spec in manifest['release']:
    for cmd in spec['commands']:
        if cmd['kind']!='tests' or not any(lane==cmd['lane'] for lane,_ in needed):
            continue
        a=next(a for a in artifacts if a['name']==f"failure-ceiling-{spec['job_id']}-{spec['matrix_index']}-1")
        directory=root/f"evidence/raw/{a['id']}/{cmd['id']}"
        for stream in directory.glob('pytest*.jsonl'):
            events=[json.loads(l) for l in stream.read_text().splitlines()]
            source={'artifact_id':a['id'],'artifact_digest':a['digest'],'command_receipt':json.loads((directory/'command.json').read_text()),'command_receipt_sha256':sha(directory/'command.json'),'command_text_sha256':sha(directory/'command.txt'),'stream':str(stream.relative_to(root/'evidence/raw')),'stream_sha256':sha(stream),'finish':events[-1]}
            for ev in events:
                if ev.get('event')=='report' and ev.get('subtest') is None and (cmd['lane'],ev['native_id']) in needed:
                    key=(cmd['lane'],ev['native_id'])
                    if key not in current: current[key]={'reports':[],'source':source}
                    current[key]['reports'].append(ev)

legacy={}
for lane,node in needed:
    if lane in legacy:continue
    s=old_for_lane[lane];p=old/f"raw-g2-runtime-app/{s['artifact_id']}"
    assert sha(p/'artifact.zip')==s['sha256']
    events=[json.loads(l) for l in (p/'files/events.jsonl').read_text().splitlines()]
    job=next(j for j in g2['jobs'] if j['repo']=='astrid-runtime' and j['workflow']+'/'+j['name']==lane)
    legacy[lane]=(s,p,events,job,sha(p/'files/events.jsonl'))

def prior(lane,node):
    s,p,events,job,event_sha=legacy[lane]
    reps=[r for r in events if r.get('event')=='test_report' and r.get('nodeid')==node and not r.get('subtest')]
    assert len(reps)==3
    return {'artifact_id':s['artifact_id'],'artifact_sha256':s['sha256'],'events_sha256':event_sha,'source_url':f"https://github.com/banodoco/astrid-runtime/actions/runs/{job['run_id']}/artifacts/{s['artifact_id']}",'job':{k:job[k] for k in ['id','sha','attempt','run_id','url']},'native_reports':reps,'summary_outcome':job['outcomes'][node]}

rows=[]
for r in new:
    lane,node=r['lane'],r['native_id'];past=prior(lane,node);now=current[(lane,node)]
    assert all(x['outcome']=='passed' for x in past['native_reports'])
    bad=[x for x in now['reports'] if x['outcome']=='failed'];assert len(bad)==1 and bad[0]['stage']=='call'
    frames=re.findall(r'^([^\n]+?\.py):(\d+)(?:: in ([^\n]+))?',bad[0]['detail'],re.M)
    routing=({'row':'RT12','source':'https://github.com/banodoco/astrid-dev/blob/ef0544ed6780352d0a58dba3d4c0e9d500191d2c/plans/39-green-mains/tasks.md','status':'Previously routed intermittent, not diagnosed anew','reason':'Exact task ID and native proc_signal_with_audittoken errno 3 signature match standing RT12 description; no attribution to P39-29.'} if 'authenticated_delayed_cleanup_ack' in node else {'row':None,'status':'Lead disposition required; no matching specific row established','reason':'Native artifact drift assertion names packages/typescript/package.json. Possible gate-introduced manifest defect; no source bisection or product fix attempted.'})
    rows.append({'lane':lane,'native_id':node,'parameter':r['parameter'],'subtest':None,'g2':past,'current':now,'stage':'call','normalized_diagnostic':r['diagnostic'],'first_recorded_test_or_product_frame':frames[0] if frames else None,'recorded_frames':frames,'routing':routing})
recoveries=[]
for lane,r in recovering:
    now=current[(lane,r['nodeid'])];assert all(x['outcome']=='passed' for x in now['reports'])
    recoveries.append({'lane':lane,'native_id':r['nodeid'],'prior_owner':r.get('owner'),'g2':prior(lane,r['nodeid']),'g2_failed_row':r,'current':now,'disposition':'Observed PASS only; previous failure retained; no qualification or causal fix claim.'})
assert len(rows)==len(recoveries)==4
out={'schema':1,'packet':'R14-P39-29','g2_report_sha256':sha(old/'g2-report.json.gz'),'current_sha':'97321788fab40400878f9abf1860a7adbf6ddb92','current_run_ids':[44462380054,44462380084],'method':'Exact lane + native ID + parameter/subtest comparison, authenticated original G2 archives, all setup/call/teardown native reports retained. Equal aggregate failures do not mean equal identities.','new_failed_lane_identities':rows,'offsetting_recovered_lane_identities':recoveries,'action':'Report 3 manifest-drift failures and RT12 recurrence to Lead; no source, tests or policy changes authorized in this packet.'}
p=root/'evidence/new-failure-routing.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(str(p),p.stat().st_size,sha(p))
for r in rows:print('PASS->FAIL',r['lane'],r['native_id'],r['current']['source']['artifact_id'],r['g2']['artifact_id'],r['first_recorded_test_or_product_frame'])
for r in recoveries:print('FAIL->PASS',r['lane'],r['native_id'])
