"""Read-only R14-P39-29 historical comparison; does not grant policy authority."""
from pathlib import Path
from collections import Counter, defaultdict
import gzip
import hashlib
import importlib.util
import json

ROOT = Path('/workspace/scratch/84d992308703')
REPO = ROOT / 'astrid-runtime'
OLD = Path('/workspace/scratch/984232aa1788/evidence-research')
SHA = '97321788fab40400878f9abf1860a7adbf6ddb92'
spec = importlib.util.spec_from_file_location('hosted', REPO / 'scripts/ci/ceiling_hosted.py')
hosted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hosted)
core = hosted.core

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes())

def norm(s):
    return core.diagnostic(s)

def dh(s):
    return hashlib.sha256(s.encode()).hexdigest()

seed_path = REPO / 'ci/evidence/p39-k2-k3/seed-summary.json'
seed = read(seed_path)
assert seed['admitted'] == 0 and seed['explicit_candidates_not_admitted'] == 349
exclusions = {(r['lane'], r['native_id']): r for r in seed['not_admitted']}
assert len(exclusions) == 349
inputs = {'seed_summary_sha256': sha(seed_path), 'required_checks_sha256': sha(REPO/'ci/required-checks.json')}
reports = {}
old_jobs = {}
old_rows = {}
for prefix in ['g1', 'g2']:
    path = OLD / (prefix + '-report.json.gz')
    actual = sha(path)
    assert actual == seed['authority'][prefix + '_report_sha256']
    reports[prefix] = read(path)
    inputs[prefix + '_report'] = {'path': str(path), 'sha256': actual, 'bytes': path.stat().st_size}
    jobs = {j['workflow'] + '/' + j['name']: j for j in reports[prefix]['jobs'] if j['repo'] == 'astrid-runtime'}
    old_jobs[prefix] = jobs
    indexed = defaultdict(list)
    for lane, j in jobs.items():
        for row in j.get('rows', []):
            indexed[(lane, row.get('nodeid'), core.canonical(row.get('context') if row.get('subtest') else None))].append(row)
    old_rows[prefix] = indexed

legacy = {}
legacy_failed_events = defaultdict(list)
inputs['g2_native_artifacts'] = []
for source in seed['source_artifacts']:
    aid, lane = source['artifact_id'], source['lane']
    base = OLD / f'raw-g2-runtime-app/{aid}'
    assert sha(base/'artifact.zip') == source['sha256']
    inv = read(base/'native-inventory.json')
    assert not inv['missing_teardowns'] and not inv['unexpected_teardowns'] and not inv['checker_errors']
    legacy[lane] = inv
    for event_line in (base/'files/events.jsonl').read_text().splitlines():
        event = json.loads(event_line)
        if event.get('event')=='test_report' and event.get('outcome')=='failed':
            key=(lane,event['nodeid'],core.canonical(event.get('context') if event.get('subtest') else None))
            legacy_failed_events[key].append(event)
    inputs['g2_native_artifacts'].append({'lane': lane, 'artifact_id': aid, 'archive_sha256': source['sha256'], 'native_inventory_sha256': sha(base/'native-inventory.json'), 'events_sha256': sha(base/'files/events.jsonl')})

manifest = read(REPO/'ci/required-checks.json')
runs = {k: read(ROOT/f'evidence/source/run-{suffix}.json') for k,suffix in [('CI','ci'),('Nightly','nightly')]}
jobs = {k: read(ROOT/f'evidence/source/jobs-{suffix}.json')['jobs'] for k,suffix in [('CI','ci'),('Nightly','nightly')]}
artifacts = [a for a in read(ROOT/'evidence/source/artifacts.json') if a['name'].startswith('failure-ceiling-')]
roots = [ROOT / f'evidence/raw/{a["id"]}' for a in artifacts]
artifact_by_root = {p: a for p,a in zip(roots, artifacts)}
current_jobs=[]
current_failed_events = defaultdict(list)
current_sources = {}
for required in manifest['release']:
    run=runs[required['workflow']]
    assert run['status']=='completed'
    raw=next(j for j in jobs[required['workflow']] if j['name']==required['job'])
    current_jobs.append(hosted.normalized_job(required, raw, run, roots, 'banodoco/astrid-runtime', SHA, REPO, {'banodoco/astrid-runtime': SHA}))
    artifact=next(a for a in artifacts if a['name']==f"failure-ceiling-{required['job_id']}-{required['matrix_index']}-1")
    for command in required['commands']:
        if command['kind']!='tests':continue
        directory=ROOT/f"evidence/raw/{artifact['id']}/{command['id']}"
        for stream in directory.glob('pytest*.jsonl'):
            source={'artifact_id':artifact['id'],'artifact_digest':artifact['digest'],'stream':str(stream.relative_to(ROOT/'evidence/raw')),'stream_sha256':sha(stream),'command_receipt_sha256':sha(directory/'command.json'),'command_text_sha256':sha(directory/'command.txt')}
            for event_line in stream.read_text().splitlines():
                event=json.loads(event_line)
                if event.get('event')=='report' and event.get('outcome')=='failed':
                    key=(command['lane'],event['native_id'],core.canonical(event.get('subtest')))
                    current_failed_events[key].append(event)
                    current_sources[key]=source

failed=[]
current_census=Counter()
for job in current_jobs:
    for suite in job['suites']:
        for test in suite['tests']:
            current_census[test['outcome']]+=1
            if test['outcome'] != 'failed':
                continue
            lane, node = test['lane'], test['native_id']
            key=(lane,node,core.canonical(test.get('subtest')))
            record={**test,
                    'identity_sha256': core.digest(list(core.identity(test))),
                    'diagnostic_sha256': dh(test['diagnostic']),
                    'original_receipt': {k:job[k] for k in ['workflow','job','job_id','run_id','attempt','head','tuple','started_at']},
                    'native_step': suite['name'], 'native_raw_exit': suite['raw_exit'],
                    'historical_exclusion': exclusions.get((lane,node)),
                    'g1':[], 'g2':[]}
            record['current_native_source']=current_sources[key]
            current_events=current_failed_events[key]
            previous_events=legacy_failed_events.get(key,[])
            current_messages=[{'stage':e['stage'],'detail_sha256':dh(e.get('detail','')),'error_message':core.error_message(e.get('detail',''))} for e in current_events]
            previous_messages=[{'stage':e['when'],'detail_sha256':dh(e.get('detail','')),'error_message':core.error_message(e.get('detail',''))} for e in previous_events]
            record['native_detail_comparison']={'method':'Apply unchanged trusted core.error_message to both original native detail fields. This auxiliary representation comparison does not replace comparator diagnostics or establish causal equivalence.','current':current_messages,'g2':previous_messages}
            a=[(x['stage'],x['error_message']) for x in current_messages]
            b=[(x['stage'],x['error_message']) for x in previous_messages]
            record['g2_native_relationship']=('same_native_identity_stage_and_error_message' if a==b else 'same_native_identity_and_stage_error_message_differs' if [x[0] for x in a]==[x[0] for x in b] else 'no_matching_historical_failure_stage')
            for prefix in ['g1','g2']:
                historical_job=old_jobs[prefix].get(lane)
                matches=old_rows[prefix].get(key,[])
                record[prefix+'_job_present']=historical_job is not None
                for row in matches:
                    diagnostic=norm(row.get('full_message') or row.get('message') or '')
                    phase=row.get('phase') or row.get('when')
                    phases=row.get('failure_phases')
                    if prefix=='g2':
                        native_phases=legacy.get(lane,{}).get('primary_reports',{}).get(node,[])
                        failures=[r['when'] for r in native_phases if r.get('outcome')=='failed']
                    else:
                        native_phases=None
                        failures=[]
                    matched_phase='+'.join(failures) if failures else phase
                    record[prefix].append({
                        'job': {k:historical_job.get(k) for k in ['id','name','repo','workflow','run_id','sha','attempt','status','conclusion','url']},
                        'recorded_row': row,
                        'normalized_diagnostic':diagnostic,
                        'normalized_diagnostic_sha256':dh(diagnostic),
                        'diagnostic_equal':diagnostic==test['diagnostic'],
                        'declared_phase':phase,
                        'declared_failure_phases':phases,
                        'verified_native_phases':native_phases,
                        'verified_failure_stage':'+'.join(failures) if failures else None,
                        'stage_equal':matched_phase==test['stage'] if matched_phase else None,
                        'g1_call_phase_indication':row.get('outcome') in ['FAILED','SUBFAILED'] if prefix=='g1' else None,
                        'causal_equivalence_claimed':False,
                    })
            g2=record['g2']
            if len(g2)!=1:
                record['g2_relationship']='unmatched_or_ambiguous_historical_failure'
            elif g2[0]['diagnostic_equal'] and g2[0]['stage_equal']:
                record['g2_relationship']='same_native_identity_stage_and_normalized_diagnostic'
            elif g2[0]['stage_equal']:
                record['g2_relationship']='same_native_identity_and_stage_diagnostic_differs'
            else:
                record['g2_relationship']='same_native_identity_stage_differs_or_unproven'
            g1=record['g1']
            if not record['g1_job_present']:
                record['g1_relationship']='historical_lane_absent'
            elif not g1:
                record['g1_relationship']='not_in_historical_failed_rows_no_pass_inferred'
            elif len(g1)!=1:
                record['g1_relationship']='ambiguous_historical_failed_rows'
            elif g1[0]['diagnostic_equal']:
                record['g1_relationship']='same_native_identity_and_normalized_diagnostic_stage_as_recorded'
            else:
                record['g1_relationship']='same_native_identity_diagnostic_differs'
            record['disposition']='Remain uncovered/red; no failure ceiling admission or causal disposition authorized in PASS-inventory packet.'
            failed.append(record)

assert len(failed)==1630
assert len({core.identity(r) for r in failed})==1630
matched_exclusions=[r for r in failed if r['historical_exclusion']]
assert len(matched_exclusions)==349
assert {(r['lane'],r['native_id']) for r in matched_exclusions}==set(exclusions)
for row in failed:
    assert row['subtest'] is None
counts=lambda attr,rows=failed:dict(sorted(Counter(r[attr] for r in rows).items()))
summary={
    'current_outcome_census':dict(current_census),
    'failed_lane_identities':len(failed),
    'failed_subtest_identities':sum(r.get('subtest') is not None for r in failed),
    'stages':counts('stage'),
    'explicit_historical_exclusions_preserved':len(matched_exclusions),
    'outside_explicit_exclusions':len(failed)-len(matched_exclusions),
    'historical_exclusion_reasons':dict(Counter(r['historical_exclusion']['reason'] for r in matched_exclusions)),
    'g2_relationships':counts('g2_relationship'),
    'g2_native_error_relationships':counts('g2_native_relationship'),
    'g1_relationships':counts('g1_relationship'),
    'outside_explicit_exclusions_g2':counts('g2_relationship',[r for r in failed if not r['historical_exclusion']]),
    'outside_explicit_exclusions_g2_native_errors':counts('g2_native_relationship',[r for r in failed if not r['historical_exclusion']]),
    'outside_explicit_exclusions_g1':counts('g1_relationship',[r for r in failed if not r['historical_exclusion']]),
    'g2_owner_rows':dict(sorted(Counter((r['g2'][0]['recorded_row'].get('owner_row') or r['g2'][0]['recorded_row'].get('owner') or 'unowned') if len(r['g2'])==1 else 'unmatched' for r in failed).items())),
    'g2_already_flagged_possible_product_bug':sum(any(x['recorded_row'].get('possible_product_bug') for x in r['g2']) for r in failed),
}
nine_path=REPO/'ci/evidence/p39-k2-k3/nine-id-reconciliation.json.gz'
nine=read(nine_path)
result={'schema':1,'packet':'R14-P39-29','source_sha':SHA,'method':'Read-only unchanged destination normalizer over original required artifacts; exact native identity joins to hash-authenticated G1/G2 reports. G2 stages independently bound to six original native archives. No historical pass inferred from absent failure rows, no causal equivalence inferred from matching messages. All 349 exclusions and all 1,630 failures stay refused.','inputs':inputs,'summary':summary,'nine_literal_ids':{'sha256':sha(nine_path),'approved_alias_count':nine.get('approved_alias_count'),'approved_coverage_mapping_count':nine.get('approved_coverage_mapping_count'),'complete_reconciliation_approved':nine.get('complete_reconciliation_approved'),'status':'Preserved unchanged; no new aliases or title matching.'},'failures':sorted(failed,key=lambda r:core.key_text(core.identity(r)))}
out=ROOT/'evidence/historical-failure-map.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,indent=2))
print('output',out,'bytes',out.stat().st_size,'sha256',sha(out))
