"""Inspect original Runtime receipts with destination-owned adapters; writes evidence only."""
from pathlib import Path
from collections import Counter
import ast
import gzip
import hashlib
import importlib.util
import json
import subprocess

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'astrid-runtime'
EVIDENCE = ROOT / 'evidence'
HEAD = '97321788fab40400878f9abf1860a7adbf6ddb92'
REPOSITORY = 'banodoco/astrid-runtime'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def frozen(path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{HEAD}:{path}'])

def module(name):
    assert (REPO / 'scripts/ci' / (name + '.py')).read_bytes() == frozen('scripts/ci/' + name + '.py')
    spec = importlib.util.spec_from_file_location(name, REPO / 'scripts/ci' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

hosted = module('ceiling_hosted')
core = hosted.core
for script in ('failure_ceiling.py', 'ceiling_adapters.py'):
    assert (REPO / 'scripts/ci' / script).read_bytes() == frozen('scripts/ci/' + script)
checks = json.loads(frozen('ci/required-checks.json'))
inventory = json.loads(gzip.decompress(frozen('ci/test-inventory.json.gz')))
seed = {core.identity(r): r for r in inventory['tests']}
artifacts = json.loads((EVIDENCE / 'source/artifacts.json').read_text())
native_artifacts = [a for a in artifacts if a['name'].startswith('failure-ceiling-')]
artifact_by_id = {a['id']: a for a in native_artifacts}
roots = [EVIDENCE / 'raw' / str(a['id']) for a in native_artifacts]
for artifact in native_artifacts:
    assert not artifact['expired']
    assert 'sha256:' + sha(EVIDENCE / 'raw' / (str(artifact['id']) + '.zip')) == artifact['digest']

git_tree = subprocess.check_output(['git', '-C', str(REPO), 'ls-tree', '-r', HEAD], text=True)
blob_by_path = {line.split('\t', 1)[1]: line.split('\t', 1)[0].split()[2] for line in git_tree.splitlines()}
ast_cache = {}

def declaration(native_id):
    if native_id.startswith('['):
        file, line, column, nesting, name = json.loads(native_id)
        # The CI workflow uses packages/typescript as its recorded working directory.
        path = 'packages/typescript/' + file
        text = (REPO / path).read_text()
        declaration_line = text.splitlines()[line - 1]
        assert 'test(' in declaration_line, (path, line, name)
        return {
            'mapping': 'native Node tuple: file, line, column, nesting, title; workflow working-directory packages/typescript',
            'native_tuple': json.loads(native_id), 'file': path, 'line': line,
            'column': column, 'declaration': text.splitlines()[line - 1],
            'literal_title_matches_declaration': name in declaration_line,
            'source_context': text.splitlines()[max(0, line - 4):line],
            'git_blob': blob_by_path[path], 'sha256': sha(REPO / path),
            'url': f'https://github.com/{REPOSITORY}/blob/{HEAD}/{path}#L{line}',
        }
    file, *components = native_id.split('::')
    components[-1] = components[-1].split('[', 1)[0]
    if file not in ast_cache:
        text = (REPO / file).read_text()
        ast_cache[file] = (text, ast.parse(text))
    text, current = ast_cache[file]
    for component in components:
        matches = [x for x in current.body if isinstance(x, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and x.name == component]
        assert len(matches) == 1, (native_id, component, len(matches))
        current = matches[0]
    subtest_sites = []
    for node in ast.walk(current):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in {'subTest', 'test'}:
            if node.func.attr == 'subTest' or isinstance(node.func.value, ast.Name) and node.func.value.id == 'subtests':
                subtest_sites.append({'line': node.lineno, 'expression': ast.get_source_segment(text, node)})
    return {
        'mapping': 'native pytest file/class/function, preserving full parameter suffix separately',
        'file': file, 'qualified_name': '::'.join(components), 'line': current.lineno,
        'end_line': current.end_lineno, 'declaration': text.splitlines()[current.lineno - 1],
        'git_blob': blob_by_path[file], 'sha256': sha(REPO / file),
        'subtest_declarations': subtest_sites,
        'url': f'https://github.com/{REPOSITORY}/blob/{HEAD}/{file}#L{current.lineno}',
    }

rows = []
per_command = []
normalized_jobs = []
observed = {}
for spec in checks['release']:
    label = 'ci' if spec['workflow'] == 'CI' else 'nightly'
    run = json.loads((EVIDENCE / 'source' / f'run-{label}.json').read_text())
    jobs = json.loads((EVIDENCE / 'source' / f'jobs-{label}.json').read_text())['jobs']
    assert run['status'] == 'completed' and run['head_sha'] == HEAD
    matches = [j for j in jobs if j['name'] == spec['job']]
    assert len(matches) == 1
    raw = matches[0]
    normalized = hosted.normalized_job(spec, raw, run, roots, REPOSITORY, HEAD, REPO, {REPOSITORY: HEAD})
    assert normalized['commands_complete']
    normalized_jobs.append(normalized)
    receipts = {}
    for root in roots:
        found = hosted.read_command(root, spec, normalized, REPOSITORY, HEAD, REPO)
        assert not receipts.keys() & found.keys()
        receipts.update(found)
    for command in (c for c in spec['commands'] if c['kind'] == 'tests'):
        directory, receipt = receipts[command['id']]
        artifact_id = int(directory.parent.name)
        artifact = artifact_by_id[artifact_id]
        suites = [s for s in normalized['suites'] if s['name'] == command['id']]
        streams = [p for p in sorted(directory.glob('*.jsonl')) if not hosted.adapters.stream(p)[0].get('collect_only')]
        assert len(suites) == len(streams) == command.get('invocations', 1)
        for suite, stream in zip(suites, streams):
            events = hosted.adapters.stream(stream)
            native_events = [(index + 1, e) for index, e in enumerate(events) if e['event'] in {'result', 'report'}]
            existing_count = sum(core.identity(t) in seed for t in suite['tests'])
            command_key = f"{spec['workflow']}/{spec['job']}/{command['id']}"
            evidence = {
                'key': command_key, 'workflow': spec['workflow'], 'job': spec['job'],
                'workflow_file': spec['workflow_file'], 'job_id': raw['id'],
                'run_id': run['id'], 'attempt': normalized['attempt'],
                'run_status': run['status'], 'run_conclusion': run['conclusion'],
                'job_status': raw['status'], 'job_conclusion': raw['conclusion'],
                'source_head': HEAD, 'lane': command['lane'], 'step': command['id'],
                'workflow_source_blob': blob_by_path['.github/workflows/' + spec['workflow_file']],
                'workflow_source_sha256': hashlib.sha256(frozen('.github/workflows/' + spec['workflow_file'])).hexdigest(),
                'step_name': command['name'], 'command': (directory / 'command.txt').read_text(),
                'command_sha256': sha(directory / 'command.txt'),
                'command_receipt_sha256': sha(directory / 'command.json'),
                'command_log_sha256': sha(directory / 'command.log'),
                'dependency_tuple': receipt['tuple'],
                'expected_dependency_tuple': {**command.get('dependency_tuple', spec.get('dependency_tuple', {})), REPOSITORY: HEAD},
                'command_receipt': receipt,
                'raw_command_exit': receipt['raw_exit'], 'native_exit': suite['raw_exit'],
                'native_stream': str(stream.relative_to(EVIDENCE / 'raw' / str(artifact_id))),
                'native_stream_sha256': sha(stream), 'native_start': events[0], 'native_finish': events[-1],
                'artifact_id': artifact_id, 'artifact_digest': artifact['digest'],
                'artifact_size': artifact['size_in_bytes'],
                'artifact_url': f'https://github.com/{REPOSITORY}/actions/runs/{run["id"]}/artifacts/{artifact_id}',
                'job_url': raw['html_url'], 'native_count': len(suite['tests']),
                'native_outcomes': dict(Counter(t['outcome'] for t in suite['tests'])),
                'sealed_count': existing_count,
            }
            assert evidence['dependency_tuple'] == evidence['expected_dependency_tuple']
            per_command.append(evidence)
            for result in suite['tests']:
                ident = core.identity(result)
                assert ident not in observed
                observed[ident] = result
                if ident in seed or result['outcome'] != 'passed':
                    continue
                proposed = {k: result[k] for k in ('lane', 'native_id', 'parameter', 'subtest')}
                if 'source' in result:
                    proposed['source'] = result['source']
                native_matches = [(line, e) for line, e in native_events
                                  if e['native_id'] == result['native_id'] and e.get('subtest') == result['subtest']]
                assert native_matches
                if result['subtest'] is None and suite['format'] == 'pytest':
                    assert Counter(e['stage'] for _, e in native_matches) == Counter({'setup': 1, 'call': 1, 'teardown': 1})
                assert all(e['outcome'] == 'passed' for _, e in native_matches)
                source = declaration(result['native_id'])
                if result['subtest'] is not None:
                    assert source['subtest_declarations'], result['native_id']
                parent = next((t for t in suite['tests'] if t['native_id'] == result['native_id'] and t['subtest'] is None), None)
                if result['subtest'] is not None:
                    assert parent is not None and core.identity(parent) in seed
                    assert parent['outcome'] == 'passed' and parent['subtests_failed'] == 0
                rows.append({
                    'proposed_row': proposed,
                    'identity_digest': hashlib.sha256(core.key_text(ident).encode()).hexdigest(),
                    'result': result,
                    'command_evidence_key': command_key,
                    'native_event_records': [{'line': line, 'event': event} for line, event in native_matches],
                    'source': source,
                    'native_separate_source_field': result.get('source'),
                    'source_binding_note': 'No separate native source field was emitted; source is retained by the full native identity and resolved against the unchanged source declaration.',
                    'subtest_encoding_note': 'Exact native SubtestContext string preserved; no parse, flattening or aliasing.' if result['subtest'] is not None else None,
                    'parent_result': parent if result['subtest'] is not None else None,
                    'parent_already_seeded': True if result['subtest'] is not None else None,
                })

rows.sort(key=lambda x: core.key_text(core.identity(x['proposed_row'])))
assert len(rows) == 437
assert len({core.identity(x['proposed_row']) for x in rows}) == 437
assert sum(x['proposed_row']['subtest'] is not None for x in rows) == 180
assert len(seed) == 30871 and len(observed) == 31322
assert not set(seed) - set(observed)
out = {
    'packet': 'R14-P39-29', 'source_head': HEAD, 'purpose': 'Evidence extraction; no new policy or qualification',
    'destination_adapters': {p.name: sha(p) for p in [REPO/'scripts/ci/ceiling_hosted.py', REPO/'scripts/ci/ceiling_adapters.py', REPO/'scripts/ci/failure_ceiling.py']},
    'sealed_inventory_sha256': hashlib.sha256(frozen('ci/test-inventory.json.gz')).hexdigest(),
    'required_checks_sha256': hashlib.sha256(frozen('ci/required-checks.json')).hexdigest(),
    'normalization': {'required_jobs': len(normalized_jobs), 'native_invocations': len(per_command), 'complete_commands': all(j['commands_complete'] for j in normalized_jobs), 'collection_errors': [], 'unexplained_failed_steps': {j['job']:j['unexplained_failed_steps'] for j in normalized_jobs if j['unexplained_failed_steps']}},
    'counts': {'sealed': len(seed), 'observed': len(observed), 'missing_seeded': len(set(seed)-set(observed)), 'unseeded_pass': len(rows), 'subtest_pass': sum(r['proposed_row']['subtest'] is not None for r in rows), 'by_lane': dict(Counter(r['proposed_row']['lane'] for r in rows))},
    'commands': per_command,
    'pass_additions': rows,
}
(EVIDENCE/'pass-identity-audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
md = f'''# R14-P39-29 original PASS identity audit

The unchanged destination normalizer at `{HEAD}` accepted all ten original job envelopes and all thirteen native invocations. All archived ZIP SHA256 values match the GitHub artifact metadata. There are **437** distinct unseeded PASS identities, including **180 exact native subtest-context strings**. All 30,871 seeded identities appear in the 31,322-identity native union.

| Lane | Proposed PASS additions |
| --- | ---: |
'''
for lane, count in sorted(out['counts']['by_lane'].items()):
    md += f'| `{lane}` | {count} |\n'
md += '''
Every proposed row is limited to the native lane, native ID, parameter and subtest (plus a separate native source field only if one was emitted). None introduces an omission allowance. For these streams no separate source field is emitted. Python file/class/function declarations and the Node native file/line/column/nesting/title tuple are mapped to unchanged source blobs in the detailed audit; the Node file prefix comes from the workflow's `packages/typescript` working directory. Parameter values and SubtestContext strings are preserved verbatim, including nested escaped values.

Each identity links to its original complete command receipt, exact command text, command/stream/archive digests, job and run, raw command and native exits, full dependency tuple, and original native report line(s). The 180 subtest passes come from three failing streams with raw exit 1; the evidence never turns those failing commands into passing commands. Their parent identities remain distinct and untouched.

This audit does not grant any skipped/xfail identity an allowance, change the zero-entry failure ceiling, dismiss any existing failure, or qualify a later release tuple. Root owns the inventory implementation and trusted before/after evaluator receipts.
'''
(EVIDENCE/'pass-identity-audit.md').write_text(md)
print(json.dumps(out['counts'],indent=2))
print(json.dumps(out['normalization'],indent=2))
print('audit_sha256',sha(EVIDENCE/'pass-identity-audit.json'))
