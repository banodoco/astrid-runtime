"""Read-only R14-P39-29 omission evidence extraction from original receipts."""
from __future__ import annotations
import ast
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'astrid-runtime'
EVIDENCE = ROOT / 'evidence'
SHA = '97321788fab40400878f9abf1860a7adbf6ddb92'
assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip() == SHA
spec=importlib.util.spec_from_file_location('trusted_adapters',REPO/'scripts/ci/ceiling_adapters.py')
adapters=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapters)
core=adapters.core
digest=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
checks=json.loads((REPO/'ci/required-checks.json').read_text())
inventory=json.loads(gzip.decompress((REPO/'ci/test-inventory.json.gz').read_bytes()))
seed={core.identity(t):t for t in inventory['tests']}
artifacts={str(a['id']):a for a in json.loads((EVIDENCE/'source/artifacts.json').read_text())}
jobs={}
for stem in ['ci','nightly']:
 for j in json.loads((EVIDENCE/f'source/jobs-{stem}.json').read_text())['jobs']:
  jobs[j['name']]=j
artifact_by_job={('unit','0'):'14504120479',('unit','1'):'14504167097',
 ('windows-realm-publication','0'):'14503649687',('darwin-native','0'):'14505142580',
 ('typescript-client','0'):'14502560824',('boundary','0'):'14503019655',
 ('sandbox-process-control','0'):'14505574545',('portability-lifecycle','0'):'14505437046',
 ('portability-lifecycle','1'):'14505920580',('integration','0'):'14504397024'}
streams={}
all_rows=[]
for job in checks['release']:
 if job['kind']!='tests':continue
 aid=artifact_by_job[(job['job_id'],job['matrix_index'])]
 archive=EVIDENCE/'raw'/f'{aid}.zip'
 assert 'sha256:'+digest(archive.read_bytes())==artifacts[aid]['digest']
 for command in job['commands']:
  if command['kind']!='tests':continue
  folder=EVIDENCE/'raw'/aid/command['id']
  receipt=json.loads((folder/'command.json').read_text())
  assert digest((folder/'command.txt').read_bytes())==receipt['command_sha256']
  assert receipt['head']==SHA
  for p in folder.glob('*.jsonl'):
   events=adapters.stream(p)
   if events[0].get('collect_only'):continue
   suite=(adapters.pytest_result if p.name.startswith('pytest-') else adapters.native_stream)(p,command['lane'],command['id'])
   lane=command['lane']
   platform='windows' if 'windows' in lane else 'macos' if 'macos' in lane or 'darwin' in lane else 'linux'
   record={
    'lane':lane,'platform':platform,'source_revision':SHA,
    'run_id':int(receipt['run_id']),'job_id':jobs[job['job']]['id'],'attempt':int(receipt['attempt']),
    'job':job['job'],'workflow':job['workflow'],'artifact_id':int(aid),
    'artifact_url':f"https://github.com/banodoco/astrid-runtime/actions/runs/{receipt['run_id']}/artifacts/{aid}",
    'artifact_sha256':digest(archive.read_bytes()),'step':command['id'],'command_name':command['name'],
    'command':(folder/'command.txt').read_bytes().decode('utf-8'),'command_sha256':receipt['command_sha256'],
    'receipt_sha256':digest((folder/'command.json').read_bytes()),
    'command_log_sha256':digest((folder/'command.log').read_bytes()),
    'native_stream':p.name,'native_stream_sha256':digest(p.read_bytes()),
    'dependency_tuple':receipt['tuple'],'command_raw_exit':receipt['raw_exit'],
    'native_raw_exit':suite['raw_exit'],'complete':suite['complete'],
   }
   key=f'{aid}/{command["id"]}/{p.name}'
   streams[key]=record
   phases={}
   for i,event in enumerate(events,1):
    if event['event']=='report' and event.get('subtest') is None:
     phases.setdefault(event['native_id'],[]).append({'stream_line':i,**event})
   for test in suite['tests']:
    all_rows.append({'test':test,'stream':key,'phases':phases.get(test['native_id'],[])})

source_cache={}
def source_file(path):
 if path not in source_cache:
  p=REPO/path;raw=p.read_bytes();text=raw.decode()
  source_cache[path]={'path':path,'source_revision':SHA,'sha256':digest(raw),
   'git_blob':subprocess.check_output(['git','-C',str(REPO),'hash-object',path],text=True).strip(),
   'url':f'https://github.com/banodoco/astrid-runtime/blob/{SHA}/{path}',
   'text':text,'tree':ast.parse(text)}
 return source_cache[path]

def excerpt(path,node):
 s=source_file(path)
 return {'path':path,'line':node.lineno,'end_line':node.end_lineno,
         'text':ast.get_source_segment(s['text'],node),'source_revision':SHA,
         'url':s['url']+f'#L{node.lineno}','file_sha256':s['sha256'],'git_blob':s['git_blob']}

def declaration(native_id):
 file,name=native_id.split('::',1);name=name.split('[')[0]
 nodes=[n for n in ast.walk(source_file(file)['tree']) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
 assert len(nodes)==1,(native_id,len(nodes))
 n=nodes[0]
 return {'path':file,'name':name,'line':n.lineno,'end_line':n.end_lineno,
         'source_revision':SHA,'url':source_file(file)['url']+f'#L{n.lineno}',
         'file_sha256':source_file(file)['sha256'],'git_blob':source_file(file)['git_blob'],
         'decorators':[excerpt(file,d) for d in n.decorator_list]}

registry={}
for n in ast.walk(source_file('tests/lanes.py')['tree']):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='_declare':
  name,condition,reason,ci=[ast.literal_eval(a) for a in n.args]
  if name in ('linux-tree-custody','posix-process-groups'):
   registry[name]={'name':name,'skip_when':condition,'reason':reason,'ci':list(ci),'blocking':True,'no_ci':'','declaration':excerpt('tests/lanes.py',n)}
bindings=json.loads((REPO/'tests/skip-bindings.json').read_text())
xfail_node=next(n for n in ast.walk(source_file('tests/lanes.py')['tree']) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='DeclaredXfail' and n.args and ast.literal_eval(n.args[0])=='installed-pair-source-closure')
xfail_kw={k.arg:ast.literal_eval(k.value) for k in xfail_node.keywords}
xfail_reason=xfail_node.args[2]
reason_args=[ast.literal_eval(n) for n in xfail_reason.args]
xfail={'name':ast.literal_eval(xfail_node.args[0]),'nodeids':list(ast.literal_eval(xfail_node.args[1])),
       'reason':f'[declared-xfail:{reason_args[0]}] {reason_args[1]}',
       'raises':ast.literal_eval(xfail_node.args[3]),'strict':xfail_kw.get('strict',True),**xfail_kw,
       'declaration':excerpt('tests/lanes.py',xfail_node)}
module_mark=next(n for n in source_file('tests/test_linux_listener.py')['tree'].body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pytestmark' for t in n.targets))

def witness(row):
 t=row['test'];return {'identity':{k:t.get(k) for k in ('lane','native_id','parameter','subtest')},
  'outcome':t['outcome'],'stage':t['stage'],'diagnostic':t['diagnostic'],
  'diagnostic_sha256':digest(t['diagnostic'].encode()),'stream':row['stream'],
  'phase_outcomes':[{'stage':p['stage'],'outcome':p['outcome'],'stream_line':p['stream_line'],'wasxfail':p.get('wasxfail')} for p in row['phases']],
  'failure_native_details':[{'stage':p['stage'],'stream_line':p['stream_line'],'detail':p.get('detail','')} for p in row['phases'] if p['outcome']=='failed']}

targets=[]
for row in all_rows:
 t=row['test'];key=core.identity(t)
 if (t['lane']=='CI/windows-realm-publication/step-10' and t['outcome']=='skipped'
     or t['lane']=='CI/darwin-native' and t['outcome']=='xfailed'
     or t['lane']=='CI/unit (macos-latest)' and 'test_linux_listener.py::' in t['native_id'] and t['outcome']=='skipped'):
  ident={k:t.get(k) for k in ('lane','native_id','parameter','subtest')}
  item={'identity':ident,'outcome':t['outcome'],'stage':t['stage'],'diagnostic':t['diagnostic'],
   'diagnostic_sha256':digest(t['diagnostic'].encode()),'stream':row['stream'],
   'native_phases':row['phases'],'declaration':declaration(t['native_id']),
   'seeded':key in seed,'seed_record':seed.get(key),'trusted_allowance_present':bool(seed.get(key,{}).get('allowed_omission')),
   'disposition':'REFUSED; evidence only; Lead decision required; no candidate allowance'}
  others=[o for o in all_rows if o['test']['native_id']==t['native_id'] and o['test'].get('parameter')==t.get('parameter') and o['test'].get('subtest')==t.get('subtest') and o['test']['lane']!=t['lane']]
  if t['lane'].startswith('CI/windows'):
   name=re.search(r'\[declared:([^]]+)\]',t['diagnostic'])[1]
   b=t['native_id'] if t['native_id'] in bindings[name] else t['native_id'].split('[',1)[0]
   assert b in bindings[name]
   reg=registry[name]
   assert 'Skipped: [declared:'+name+'] '+reg['reason']==t['diagnostic']
   assert any(d['text']=='requires_'+name.replace('-','_') for d in item['declaration']['decorators'])
   item['source_registry']={**reg,'binding':b,'binding_file':'tests/skip-bindings.json',
                           'binding_file_sha256':digest((REPO/'tests/skip-bindings.json').read_bytes()),
                           'source_marker_and_native_reason_match':True,'condition_applies_to_original_platform':True}
   allowed_platforms={'linux'} if name=='linux-tree-custody' else {'linux','macos'}
   matching=[o for o in others if streams[o['stream']]['platform'] in allowed_platforms]
   item['group']='unseeded-windows-platform-skip'
   item['policy_refusal']='New inventory identities must execute PASS. A valid existing platform declaration is not an append-only inventory omission allowance.'
   item['lead_request']='Consider an explicitly trusted inventory/omission migration bound to these exact IDs, declarations, original platform and native supported-platform witnesses. This packet cannot approve or apply it.'
  elif t['lane']=='CI/darwin-native':
   assert t['native_id'] in xfail['nodeids'] and t['diagnostic']==xfail['reason']
   deco=next(d for d in item['declaration']['decorators'] if 'pytest.mark.xfail' in d['text'])
   assert 'strict=True' in deco['text'] and 'raises=KnownSourceClosureMismatch' in deco['text']
   item['source_registry']={**xfail,'source_marker_and_native_reason_match':True,
    'original_receipt_utc_date':'2026-11-19','expiry_valid_on_original_date':True,
    'strict_exception_seen_in_native_detail':any('KnownSourceClosureMismatch:' in p.get('detail','') for p in row['phases'])}
   item['group']='unseeded-darwin-declared-xfail'
   matching=[o for o in others if streams[o['stream']]['platform']=='macos']
   item['matching_platform_witness_note']='The current original Darwin invocation is the matching platform witness and remains XFAIL, not PASS. No separate passing witness for this exact ID exists in the original required artifacts. The source declaration cites older run 42602337622/job 129109610936 but that historical assertion is not re-verified here.'
   item['policy_refusal']='New inventory identity has XFAIL, not PASS, and no sealed lane allowance. Existing strict source quarantine does not authorize a new inventory row or admission to the zero-entry failure ceiling.'
   item['lead_request']='Retain issue #808 / Plan 38 ownership and the original XFAIL. Any trusted lane inventory/quarantine migration requires Lead review with the exact strict exception, reason and unchanged 2026-12-01 expiry; no product correction or Plan 38 test change here.'
  else:
   item['source_registry']=None
   item['module_skip']=excerpt('tests/test_linux_listener.py',module_mark)
   item['group']='seeded-macos-unregistered-listener-skip'
   item['policy_refusal']='Existing inventory row has observed_unapproved_omission and no allowed_omission. Source uses direct module skipif without a declared registry token or skip binding; existing rows/allowances are immutable to this packet.'
   item['lead_request']='Route declaration/policy reconciliation to Lead and the owning listener/custody row. Preserve this seeded refusal and every Linux witness failure; any source registry correction and trusted allowance migration is separate reviewed work, never a PASS addition.'
   matching=[o for o in others if streams[o['stream']]['platform']=='linux']
  item['matching_platform_witnesses']=[witness(o) for o in matching]
  item['matching_platform_witness_outcomes']=dict(Counter(o['test']['outcome'] for o in matching))
  item['matching_platform_passing_witness_present']=any(o['test']['outcome']=='passed' for o in matching)
  if not matching and t['lane']!='CI/darwin-native':item['matching_platform_witness_note']='No matching supported-platform witness in the original required artifacts.'
  targets.append(item)
assert len(targets)==51
assert Counter(t['group'] for t in targets)=={'unseeded-windows-platform-skip':13,'unseeded-darwin-declared-xfail':1,'seeded-macos-unregistered-listener-skip':37}
assert not any(t['trusted_allowance_present'] for t in targets)
used={t['stream'] for t in targets}|{w['stream'] for t in targets for w in t['matching_platform_witnesses']}
summary={g:{'count':len(ts),'with_matching_pass':sum(t['matching_platform_passing_witness_present'] for t in ts),
            'witness_outcomes':dict(Counter(w['outcome'] for t in ts for w in t['matching_platform_witnesses']))}
 for g in sorted({t['group'] for t in targets}) for ts in [[t for t in targets if t['group']==g]]}
output={'schema':1,'packet':'R14-P39-29','source_revision':SHA,
 'scope':'Evidence only. No source, test, registry, inventory, ceiling or evaluator changes.',
 'policy':{'append_only_pass':'ci/README.md; scripts/ci/failure_ceiling.py:282-304',
           'omission_refusal':'scripts/ci/failure_ceiling.py:319-329',
           'source_skip_binding':'tests/lanes.py:112-125 and :570-618',
           'strict_xfail_binding':'tests/lanes.py:333-342',
           'authority':'Lead 6998651356; Runtime 0 failure entries; 349 exclusions stay red/unknown'},
 'summary':summary,'streams':{k:streams[k] for k in sorted(used)},'records':targets,
 'source_files':{k:{f:v for f,v in x.items() if f not in ('text','tree')} for k,x in sorted(source_cache.items())},
 'known_product_defects':[{'issue':'https://github.com/banodoco/astrid-dev/issues/808',
                         'finding':'Native Darwin XFAIL confirms the specifically declared installed-pair source-closure mismatch. Existing Plan 38 ownership; no changes attempted.'}],
 'limitations':['Platform PASS witnesses use their original command-specific Agent pins. They do not qualify later release tuples.',
                'A native PASS within a raw-exit-1 job is only that exact identity witness, not a green job.',
                'No omission allowance is proposed or applied in this packet. All 51 remain refused.']}
(EVIDENCE/'omission-dispositions.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,indent=2))
print('output',EVIDENCE/'omission-dispositions.json')
