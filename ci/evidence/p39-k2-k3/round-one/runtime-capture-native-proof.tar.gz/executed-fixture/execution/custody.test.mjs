import { test } from 'node:test';
import assert from 'node:assert/strict';
test('control passes', () => assert.equal(1, 1));
test('sensitive custody identity', () => {
  if (process.env.CEILING_FIXTURE_STATE === 'inherited') throw new Error('FixtureError: missing owner fixture');
  if (process.env.CEILING_FIXTURE_STATE === 'different-cause') throw new Error('CustodyError: publication after owner loss');
  assert.equal(process.env.CEILING_FIXTURE_STATE, 'ready');
});
