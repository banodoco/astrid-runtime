"""Read-only comparison of completed local and recovered hosted RT1/RT2 receipts."""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ROOT = Path('/workspace/scratch/20e002f91ab0')
OUT = ROOT / 'evidence-original'
LOCAL = ROOT / 'evidence-local'
PRIOR = Path('/workspace/scratch/84d992308703/evidence')
BASE = '97321788fab40400878f9abf1860a7adbf6ddb92'
AGENT = '0e1543e0da2215db9cb3320cfd1083174c3c62a9'
SPECS = {
    134906035312: ('unit (ubuntu-latest)', 14504120479, 135352013255, 44462380054, 'step-13'),
    134905940661: ('unit (macos-latest)', 14504167097, 135352013303, 44462380054, 'step-13'),
    134906039914: ('sandbox-process-control', 14505574545, 135352013198, 44462380054, 'step-04'),
    134820393924: ('Nightly integration', 14504397024, 135352012926, 44462380084, 'step-13'),
}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def details(e):
    detail = str(e.get('detail', ''))
    errors = [line.strip()[1:].strip() for line in detail.splitlines() if line.startswith('E ')]
    frames = re.findall(r'(?m)^((?:runtime_protocol|astrid_runtime)/[^\n:]+\.py):(\d+)(?:: in ([^\n]+))?', detail)
    sites = re.findall(r'(?m)^((?:runtime_protocol|astrid_runtime)/[^\n:]+\.py):(\d+): (\w+Error)', detail)
    return {
        'error_lines': errors,
        'first_runtime_frame': ':'.join(frames[0][:2]) + (':' + frames[0][2] if frames[0][2] else '') if frames else None,
        'exception_site': ':'.join(sites[-1]) if sites else None,
        'detail_sha256': sha(detail.encode()),
    }


def normalize(e):
    return {
        'nodeid': e.get('nodeid') or e.get('native_id'),
        'phase': e.get('when') or e.get('stage'),
        'outcome': e['outcome'],
        'subtest': e.get('subtest'),
        'wasxfail': e.get('wasxfail'),
        **details(e),
    }


def phase_map(events):
    out = collections.defaultdict(dict)
    for raw in events:
        e = normalize(raw)
        assert not e['subtest'] and not e['wasxfail']
        assert e['phase'] not in out[e['nodeid']]
        out[e['nodeid']][e['phase']] = e
    return dict(out)


def compare(before, after):
    changes = []
    for n in sorted(set(before) | set(after)):
        b, a = before.get(n, {}), after.get(n, {})
        diffs = []
        for stage in ['setup', 'call', 'teardown']:
            x, y = b.get(stage), a.get(stage)
            if x is None or y is None:
                if x != y:
                    diffs.append({'phase': stage, 'field': 'presence', 'before': x is not None, 'after': y is not None})
                continue
            for field in ['outcome', 'error_lines', 'first_runtime_frame', 'exception_site']:
                if x[field] != y[field]:
                    diffs.append({'phase': stage, 'field': field, 'before': x[field], 'after': y[field]})
        if diffs:
            changes.append({'nodeid': n, 'changes': diffs})
    return {
        'before_ids': len(before), 'after_ids': len(after),
        'missing': sorted(set(before) - set(after)),
        'extra': sorted(set(after) - set(before)),
        'changed_native_ids': len(changes), 'changes': changes,
        'comparison_fields': ['phase presence', 'outcome', 'literal pytest E error lines', 'first Runtime traceback frame', 'exception site'],
        'detail_limit': 'Full detail hashes retained but not treated as equivalence; temporary paths and fixture repr can differ. No causal-equivalence verdict.',
    }


def summary(m):
    phases = collections.Counter()
    categories = collections.Counter()
    outcomes = collections.Counter()
    for n, ps in m.items():
        fails = []
        for p, e in ps.items():
            phases[f'{p}:{e["outcome"]}'] += 1
            if e['outcome'] == 'failed':
                fails.append(p)
                categories[(p, e['exception_site'], tuple(e['error_lines']))] += 1
        outcomes['ERROR' if any(p != 'call' for p in fails) else 'FAILED' if fails else 'PASSED'] += 1
    return {
        'native_ids': len(m), 'phases': dict(phases), 'outcomes': dict(outcomes),
        'failure_categories': [{'phase': p, 'exception_site': f, 'error_lines': list(e), 'count': c} for (p, f, e), c in categories.items()],
    }


def main():
    roster = json.loads((OUT / 'original-roster.json').read_text())
    original = collections.defaultdict(list)
    for line in gzip.decompress((OUT / 'original-native-events.jsonl.gz').read_bytes()).splitlines():
        e = json.loads(line)
        original[e['g2_job_id']].append(e)
    original = {k: phase_map(v) for k, v in original.items()}
    assert len({n for m in original.values() for n in m}) == 366

    artifacts = {a['id']: a for a in json.loads((PRIOR / 'source/artifacts.json').read_text())}
    jobs = {}
    for path in ['jobs-ci.json', 'jobs-nightly.json']:
        for j in json.loads((PRIOR / 'source' / path).read_text())['jobs']:
            jobs[j['id']] = j
    hosted = {}
    recovered = []
    all_selected_events = []
    refdir = OUT / 'hosted-973-reference'
    refdir.mkdir(exist_ok=True)
    for g2_job, (lane, aid, jid, rid, step) in SPECS.items():
        archive_path = PRIOR / 'raw' / f'{aid}.zip'
        archive = archive_path.read_bytes()
        artifact = artifacts[aid]
        job = jobs[jid]
        assert sha(archive) == artifact['digest'].removeprefix('sha256:')
        assert artifact['workflow_run']['id'] == rid and artifact['workflow_run']['head_sha'] == BASE
        assert job['head_sha'] == BASE and job['status'] == 'completed' and job['conclusion'] == 'failure'
        target = refdir / str(aid)
        target.mkdir(exist_ok=True)
        shutil.copyfile(archive_path, target / 'artifact.zip')
        dump(target / 'artifact-metadata.json', artifact)
        dump(target / 'job-metadata.json', job)
        with zipfile.ZipFile(archive_path) as z:
            streams = []
            for name in z.namelist():
                if name.startswith(step + '/') and name.endswith('.jsonl'):
                    events = [json.loads(line) for line in z.read(name).splitlines()]
                    if events[0].get('event') == 'start' and not events[0].get('collect_only'):
                        streams.append((name, events))
            assert len(streams) == 1
            name, events = streams[0]
            command = json.loads(z.read(step + '/command.json'))
            text = z.read(step + '/command.txt')
            assert command['head'] == BASE and command['complete'] and command['raw_exit'] == 1
            assert command['tuple'] == {'banodoco/astrid-runtime': BASE, 'banodoco/astrid-agent': AGENT}
            assert command['command_sha256'] == sha(text)
            assert events[-1]['event'] == 'finish' and events[-1]['exitstatus'] == 1
            selected = [e for e in events if e.get('native_id') in original[g2_job]]
            assert all(e.get('event') == 'report' for e in selected)
            mapped = phase_map(selected)
            assert set(mapped) == set(original[g2_job])
            hosted[g2_job] = mapped
            comparison = compare(original[g2_job], mapped)
            entry = {
                'lane': lane, 'g2_job_id': g2_job,
                'run_id': rid, 'job_id': jid, 'artifact_id': aid,
                'run_attempt': 1, 'runtime_sha': BASE, 'agent_sha': AGENT,
                'job_url': f'https://github.com/banodoco/astrid-runtime/actions/runs/{rid}/job/{jid}',
                'artifact_url': f'https://github.com/banodoco/astrid-runtime/actions/runs/{rid}/artifacts/{aid}',
                'archive_sha256': sha(archive), 'archive_bytes': len(archive),
                'native_stream': name, 'native_finish': events[-1],
                'command': command, 'command_text': text.decode(),
                'summary': summary(mapped), 'g2_comparison': comparison,
            }
            recovered.append(entry)
            for e in selected:
                all_selected_events.append({'g2_job_id': g2_job, 'native_job_id': jid, 'artifact_id': aid, **e})
    dump(OUT / 'hosted-973-reference.json', {'source': 'Existing archived exact973 receipts; no execution or network dispatch', 'lanes': recovered, 'native_by_g2_job': hosted})
    raw_events = ''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in all_selected_events).encode()
    (OUT / 'hosted-973-native-events.jsonl.gz').write_bytes(gzip.compress(raw_events, mtime=0))

    local_results = []
    for lane, g2_job in [('unit', 134906035312), ('nightly', 134820393924)]:
        directory = LOCAL / f'base-{lane}'
        if not (directory / 'exit.txt').exists():
            raise SystemExit(f'Waiting for completed original {directory}; tests were not launched by this script')
        invocation = json.loads((directory / 'invocation.json').read_text())
        assert invocation['head'] == BASE and invocation['agent_pin'] == AGENT and invocation['status'] == ''
        assert set(invocation['requested_nodeids']) == set(original[g2_job])
        raw = (directory / 'events.jsonl').read_bytes()
        events = [json.loads(line) for line in raw.splitlines()]
        finish = [e for e in events if e['event'] == 'finish']
        assert len(finish) == 1 and finish[0]['exitstatus'] == int((directory / 'exit.txt').read_text())
        selected = [e for e in events if e.get('event') == 'test_report']
        mapped = phase_map(selected)
        assert set(mapped) == set(original[g2_job])
        local_results.append({
            'lane': lane, 'runtime_sha': BASE, 'agent_sha': AGENT,
            'worker_environment': invocation['worker_environment'],
            'original_invocation_file': str(directory / 'invocation.json'),
            'command': invocation['command'], 'finish': finish[0],
            'native_exit': int((directory / 'exit.txt').read_text()),
            'hashes': {name: sha((directory / name).read_bytes()) for name in ['invocation.json', 'events.jsonl', 'terminal.log', 'native.xml', 'exit.txt']},
            'summary': summary(mapped),
            'g2_comparison': compare(original[g2_job], mapped),
            'hosted_973_comparison': compare(hosted[g2_job], mapped),
            'native_phases': mapped,
        })
    result = {
        'status': 'Read-only comparison of root-executed original baseline; no repair, rerun or release verdict',
        'original_g2_source': roster['source'],
        'original_runtime': '19cd1e35cd247fd394204940b6e7a02929fa3fc6',
        'baseline_runtime': BASE,
        'limitations': [
            'Local runs use CPython 3.13.5; original and exact973 hosted workflow declarations use Python 3.11.',
            'Local unit execution proves Linux only, not macOS or seccomp sandbox.',
            'Historical original G2 Runtime19cd and actual destination973 remain separately bound.',
            'Comparison retains phase absence, errors and failures; no ERROR-to-FAIL repair inference.',
            'Error lines and traceback frame comparisons do not prove causal equivalence.',
        ],
        'lanes': local_results,
    }
    dump(OUT / 'base-973-vs-g2.json', result)
    print(json.dumps({
        'hosted_reference': [{k: e[k] for k in ['lane', 'job_id', 'artifact_id', 'summary']} | {'changed_vs_g2': e['g2_comparison']['changed_native_ids']} for e in recovered],
        'local_baseline': [{k: e[k] for k in ['lane', 'native_exit', 'summary']} | {'changed_vs_g2': e['g2_comparison']['changed_native_ids'], 'changed_vs_hosted_973': e['hosted_973_comparison']['changed_native_ids']} for e in local_results],
    }, indent=2))


if __name__ == '__main__':
    main()
