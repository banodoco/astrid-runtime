"""Recover RT1/RT2 historical native evidence without mutating any repository."""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
DEV = Path('/workspace/scratch/984232aa1788/astrid-dev')
RUNTIME = Path('/workspace/scratch/20e002f91ab0/astrid-runtime')
RESEARCH = Path('/workspace/scratch/984232aa1788/evidence-research')
G2_REF = '7290367c'
G2_PATH = 'plans/39-green-mains/evidence/release-14-phase1-measurement-20261116/remeasure-g2/final-report-data.json.gz'
RUNTIME_SHA = '19cd1e35cd247fd394204940b6e7a02929fa3fc6'
AGENT_SHA = '0e1543e0da2215db9cb3320cfd1083174c3c62a9'
GROUPS = {
    'R-G2-RT1-registration': ('registration', 128),
    'R-G2-RT1-pending': ('verification-pending', 237),
    'R-G2-RT1-process-registration': ('process-registration', 1),
}
ARTIFACTS = {
    134906035312: 14433570144,
    134905940661: 14441948450,
    134906039914: 14432965131,
    134820393924: 14429154793,
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(repo), *args])


def dump(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def main() -> None:
    commit = git(DEV, 'rev-parse', G2_REF).decode().strip()
    blob = git(DEV, 'rev-parse', f'{G2_REF}:{G2_PATH}').decode().strip()
    source = git(DEV, 'show', f'{G2_REF}:{G2_PATH}')
    assert source == (RESEARCH / 'g2-report.json.gz').read_bytes()
    report = json.loads(gzip.decompress(source))
    assert report == json.loads((RESEARCH / 'g2-report.json').read_text())
    (OUT / 'g2-final-report-data.json.gz').write_bytes(source)

    groups = [c for c in report['cause_inventory'] if c['cause_id'] in GROUPS]
    assert len(groups) == 3
    ids_to_group = {}
    for c in groups:
        label, expected = GROUPS[c['cause_id']]
        assert len(set(c['distinct_test_ids'])) == c['distinct_test_id_count'] == expected
        for nodeid in c['distinct_test_ids']:
            assert nodeid not in ids_to_group
            ids_to_group[nodeid] = c['cause_id']
    assert len(ids_to_group) == 366
    jobs = {j['id']: j for j in report['jobs'] if j['id'] in ARTIFACTS}
    assert len(jobs) == 4
    evidence_events = []
    lane_summary = []
    observations = []
    manifest = []

    for job_id, artifact_id in ARTIFACTS.items():
        job = jobs[job_id]
        raw = RESEARCH / 'raw-g2-runtime-app' / str(artifact_id)
        archive = (raw / 'artifact.zip').read_bytes()
        prov = json.loads((raw / 'provenance.json').read_text())
        assert sha(archive) == prov['downloaded_sha256'] == prov['digest'].removeprefix('sha256:')
        assert prov['workflow_run']['head_sha'] == RUNTIME_SHA
        assert prov['workflow_run']['id'] == job['run_id']
        assert prov['g2_report_job_id'] == job_id
        target = OUT / 'artifacts' / str(artifact_id)
        target.mkdir(parents=True, exist_ok=True)
        (target / 'artifact.zip').write_bytes(archive)
        shutil.copyfile(raw / 'provenance.json', target / 'provenance.json')
        with zipfile.ZipFile(target / 'artifact.zip') as z:
            for name, digest in prov['extracted_files'].items():
                assert sha(z.read(name)) == digest
            events = [json.loads(line) for line in z.read('events.jsonl').splitlines()]
            collection = json.loads(z.read('collection.json'))
        finish = [e for e in events if e['event'] == 'finish']
        assert len(finish) == 1 and finish[0]['exitstatus'] == 1
        native = collections.defaultdict(list)
        for e in events:
            if e.get('nodeid') in ids_to_group:
                assert e['event'] == 'test_report'
                assert not e.get('subtest')
                native[e['nodeid']].append(e)
                evidence_events.append({'g2_job_id': job_id, 'artifact_id': artifact_id, **e})
        rows = [r for r in job['rows'] if r.get('cause_id') in GROUPS]
        assert len(rows) == len(native)
        assert set(r['nodeid'] for r in rows) == set(native)
        for row in rows:
            assert ids_to_group[row['nodeid']] == row['cause_id']
            expected_phase = row['phase']
            reports = native[row['nodeid']]
            bad = [e for e in reports if e['outcome'] == 'failed']
            assert len(bad) == 1 and bad[0]['when'] == expected_phase
            assert ('ERROR' if expected_phase != 'call' else 'FAILED') == row['outcome']
            observations.append({
                'nodeid': row['nodeid'], 'group': GROUPS[row['cause_id']][0],
                'cause_id': row['cause_id'], 'g2_job_id': job_id,
                'native_job_id': job.get('evidence_job_id') or job_id,
                'native_run_attempt': job.get('evidence_run_attempt') or job['attempt'],
                'artifact_id': artifact_id, 'run_id': job['run_id'],
                'lane': job['name'], 'workflow': job['workflow'],
                'g2_outcome': row['outcome'], 'failing_phase': expected_phase,
                'message': row['message'],
                'native_detail_sha256': sha(str(bad[0].get('detail', '')).encode()),
                'phases': [{k: e.get(k) for k in ('when', 'outcome', 'wasxfail', 'subtest')} for e in reports],
            })
        summary = {
            'g2_job_id': job_id, 'native_job_id': job.get('evidence_job_id') or job_id,
            'native_run_attempt': job.get('evidence_run_attempt') or job['attempt'],
            'inherited_attempt1_evidence': job.get('inherited_evidence', False),
            'job_name': job['name'], 'run_id': job['run_id'],
            'native_job_url': job.get('evidence_url') or job['url'],
            'artifact_id': artifact_id,
            'artifact_url': f"https://github.com/banodoco/astrid-runtime/actions/runs/{job['run_id']}/artifacts/{artifact_id}",
            'archive_sha256': sha(archive),
            'runtime_sha': RUNTIME_SHA, 'agent_sha': AGENT_SHA,
            'original_ids': len(native),
            'outcomes': dict(collections.Counter(r['outcome'] for r in rows)),
            'groups': dict(collections.Counter(GROUPS[r['cause_id']][0] for r in rows)),
            'native_phases': dict(collections.Counter(f"{e['when']}:{e['outcome']}" for es in native.values() for e in es)),
            'native_finish': finish[0], 'g2_sources': job['sources'],
        }
        lane_summary.append(summary)
        manifest.append({'path': str(target.relative_to(OUT) / 'artifact.zip'), 'sha256': sha(archive), 'bytes': len(archive), 'payloads': prov['extracted_files']})
        (OUT / f"ids-{job_id}.txt").write_text('\n'.join(sorted(native)) + '\n')
    assert len(observations) == 1082
    assert {len([o for o in observations if o['g2_job_id'] == k]) for k in ARTIFACTS} == {358, 8}
    assert len({o['nodeid'] for o in observations}) == 366

    source_identity = {
        'repository': 'banodoco/astrid-dev', 'commit': commit, 'path': G2_PATH,
        'blob': blob, 'bytes': len(source), 'sha256': sha(source),
        'url': f'https://github.com/banodoco/astrid-dev/blob/{commit}/{G2_PATH}',
        'local_report_equal_to_canonical_git_blob': True,
    }
    entries = [{
        'nodeid': nodeid, 'source_file': nodeid.split('::')[0],
        'cause_id': cid, 'group': GROUPS[cid][0],
        'observations': [o for o in observations if o['nodeid'] == nodeid],
    } for nodeid, cid in sorted(ids_to_group.items())]
    result = {
        'packet': 'R14-P39-15', 'tasks': ['RT1', 'RT2'],
        'status': 'Recovered historical evidence only; no candidate execution or repair claim.',
        'source': source_identity,
        'summary': {
            'distinct_native_ids': len(entries), 'observations': len(observations),
            'by_group': {label: expected for label, expected in GROUPS.values()},
            'by_source_file': dict(sorted(collections.Counter(e['source_file'] for e in entries).items())),
            'observation_outcomes': dict(collections.Counter(o['g2_outcome'] for o in observations)),
        },
        'lanes': lane_summary, 'ids': entries,
        'limitations': [
            'Historical G2 observations are not a destination-head baseline or candidate qualification.',
            'A failing setup prevents a native call; teardown passing does not imply the call ran.',
            'Unit Linux and sandbox metadata use attempt-2 job envelopes but their native receipts remain attempt 1.',
            'The 366 union is 358 unit/sandbox native IDs plus eight different Nightly IDs; repeated native observations are not additional IDs.',
            'Literal original command manifests and pins are saved from the Runtime G2 commit. No execution was dispatched.',
        ],
    }
    dump(OUT / 'original-roster.json', result)
    (OUT / 'original-ids.txt').write_text('\n'.join(sorted(ids_to_group)) + '\n')
    for cid, (label, _) in GROUPS.items():
        (OUT / f'ids-{label}.txt').write_text('\n'.join(sorted(n for n, c in ids_to_group.items() if c == cid)) + '\n')
    event_data = ''.join(json.dumps(e, sort_keys=True, ensure_ascii=False) + '\n' for e in evidence_events).encode()
    (OUT / 'original-native-events.jsonl.gz').write_bytes(gzip.compress(event_data, mtime=0))
    for path in ['.github/workflows/ci.yml', '.github/workflows/nightly.yml', 'tests/seccomp/run-suite.sh', 'tests/seccomp/container-entrypoint.py', 'tests/seccomp/openshell-like.json', 'tests/astrid-agent.pin', 'scripts/ci/run_pytest.py']:
        dest = OUT / 'g2-source' / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        data = git(RUNTIME, 'show', f'{RUNTIME_SHA}:{path}')
        dest.write_bytes(data)
        manifest.append({'path': str(dest.relative_to(OUT)), 'sha256': sha(data), 'bytes': len(data), 'commit': RUNTIME_SHA})
    assert (OUT / 'g2-source/tests/astrid-agent.pin').read_text().strip() == AGENT_SHA
    manifest.append(source_identity)
    for name in ['original-roster.json', 'original-ids.txt', 'original-native-events.jsonl.gz']:
        data = (OUT / name).read_bytes()
        manifest.append({'path': name, 'sha256': sha(data), 'bytes': len(data)})
    dump(OUT / 'manifest.json', manifest)
    print(json.dumps({'summary': result['summary'], 'lanes': [{k: s[k] for k in ('job_name', 'g2_job_id', 'native_job_id', 'native_run_attempt', 'artifact_id', 'original_ids', 'groups', 'outcomes', 'native_phases')} for s in lane_summary], 'source': source_identity}, indent=2))


if __name__ == '__main__':
    main()
