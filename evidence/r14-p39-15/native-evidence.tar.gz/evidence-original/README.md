# R14-P39-15 historical native evidence

Recovered without editing or executing product source, dispatching workflows, or commenting externally.

## Source and verification

Canonical G2 is `banodoco/astrid-dev` commit `7290367c170eb751ae14fd41d7f433f92b0e0e1e`, path `plans/39-green-mains/evidence/release-14-phase1-measurement-20261116/remeasure-g2/final-report-data.json.gz`, Git blob `0975f72507ddd06b2bab84a765c4bc7a6a0a4c7a`. Its 5,665,973 bytes have SHA256 `50760681220707845c9bd50e6795a0914fce9f705177359f6300ebc9324be522`. The locally recovered compressed source matches the exact Git blob byte for byte, and the parsed local report matches the canonical decompressed JSON.

Original Runtime was `19cd1e35cd247fd394204940b6e7a02929fa3fc6`; pinned Agent was `0e1543e0da2215db9cb3320cfd1083174c3c62a9`. All four archived ZIP digests and all their payload digests match the recovered API provenance and G2 records. Every scoped G2 error/failure was independently matched to the native event's same test ID, phase and outcome; all original native exits were 1. The archives preserve collection, JUnit, incremental phases and terminal logs in full.

## Census

There are exactly **366 distinct native IDs**, in three disjoint G2 groups: registration 128, verification-pending 237, process-registration 1. Their repeated execution across jobs produces **1,082 observations**, containing 1,030 setup errors and 52 failing calls. A setup error has no executed call; all 1,082 recorded teardowns passed.

| Lane | Original native job | G2 envelope | Attempt | Artifact | Scoped native outcomes |
| --- | --- | --- | --- | --- | --- |
| Unit Ubuntu | 134820394487 | 134906035312 | 1, inherited under attempt 2 | 14433570144 | 358 IDs: 343 setup ERROR, 15 call FAIL |
| Unit macOS | 134905940661 | 134905940661 | 2 | 14441948450 | 358 IDs: 343 setup ERROR, 15 call FAIL |
| Sandbox | 134820394531 | 134906039914 | 1, inherited under attempt 2 | 14432965131 | 358 IDs: 343 setup ERROR, 15 call FAIL |
| Nightly integration | 134820393924 | 134820393924 | 1 | 14429154793 | 8 IDs: 1 setup ERROR, 7 call FAIL |

All three ordinary lanes contain the same 358 IDs: 232 verification-pending and 126 registration. Nightly contributes eight different IDs: five verification-pending, two registration, one process-registration.

The CI run is `44309715979`; Nightly is `44309715980`. `original-roster.json` records exact job/artifact URLs, identity-to-observation mappings and native phases. `original-native-events.jsonl.gz` preserves every selected native event, including full traceback details, with job/artifact context; the ZIPs also retain the entire original suites, including cases outside this packet.

## Original refusal sites

| Group | Literal refusal | Exception site | Observations |
| --- | --- | --- | --- |
| verification-pending | `v33 provider/baseline verification is pending; requests and fresh pins are fenced` | `runtime_protocol/v33_lifecycle.py:300`, `require_ready` | 701 |
| registration | `migrated realm requires fresh Timeline provider registration before readiness` | `runtime_protocol/daemon.py:320` | 380 |
| process-registration | `v33 provider registration is required for this process before requests and fresh pins` | `runtime_protocol/service.py:877` | 1 |

These are observed refusal sites, not proof that a product change introduced the failures. Changing an ERROR into a FAIL would expose another failing phase; it would not make the ID passing.

## Native commands

The original checked-in workflow and runner bytes are preserved under `g2-source/` at the exact Runtime G2 commit.

Unit Linux and macOS:

```sh
python scripts/ci/run_pytest.py "$TEST_RESULTS_DIR" unit -- -q -n 2 -m "not integration and not darwin_native and not live"
```

Sandbox workflow:

```sh
mkdir -p "$TEST_RESULTS_DIR" && ASTRID_TEST_RESULTS_DIR="$TEST_RESULTS_DIR" sh tests/seccomp/run-suite.sh
```

The sandbox runs Docker `python:3.11` with the checked-in `openshell-like.json` seccomp profile, installs into an owned unprivileged workspace, and invokes the preserved wrapper with these pytest arguments:

```sh
-q -n 2 --process-control=sandbox -m "not integration and not darwin_native and not live and not needs_real_pidfd"
```

Nightly:

```sh
python scripts/ci/run_pytest.py "$TEST_RESULTS_DIR" nightly-integration -- -q -m integration
```

CI unit and Nightly use Python 3.11 and Node 22, install Runtime `.[test]` and the exact pinned Agent, and install the locked TypeScript compiler with `npm ci`. Sandbox uses its recorded Python 3.11 container and installs Node/npm from that image's apt repositories. No dependencies were repinned during this recovery.

## Reusable files

- `original-roster.json`: machine-readable 366 IDs and all 1,082 original observations.
- `original-ids.txt`: all 366 native IDs, one per line.
- `ids-134906035312.txt`: the 358 original unit Linux IDs; identical membership to the macOS/sandbox lists.
- `ids-134905940661.txt`: the 358 original unit macOS IDs.
- `ids-134906039914.txt`: the 358 original sandbox IDs.
- `ids-134820393924.txt`: the eight original Nightly IDs.
- `ids-registration.txt`, `ids-verification-pending.txt`, `ids-process-registration.txt`: original disjoint 128/237/1 groups.
- `artifacts/`: original four archived receipts plus API provenance.
- `manifest.json`: local digests and source bindings.
- `extract_roster.py`: reproducible read-only extraction and consistency assertions.

The 366 IDs span 17 source files, not only the seven files mentioned in the broad RT1 setup description. The exact per-file membership is in `original-roster.json`. Historical G2 evidence does not replace a comparison against current destination `97321788`, nor prove candidate outcomes, macOS execution, sandbox execution or current Nightly execution.
