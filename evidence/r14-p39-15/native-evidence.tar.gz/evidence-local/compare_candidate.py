"""Reconcile completed candidate receipts; no test execution or repository writes."""
from __future__ import annotations

import ast
import collections
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/20e002f91ab0')
LOCAL = ROOT / 'evidence-local'
ORIGINAL = ROOT / 'evidence-original'
REPO = ROOT / 'astrid-runtime'
BASE = '97321788fab40400878f9abf1860a7adbf6ddb92'
sys.path.insert(0, str(ORIGINAL))
from compare_baseline import phase_map, compare, sha


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def outcome(phases):
    failures = [p for p, e in phases.items() if e['outcome'] == 'failed']
    if any(p != 'call' for p in failures):
        return 'ERROR'
    if failures:
        return 'FAILED'
    if any(e['outcome'] == 'skipped' for e in phases.values()):
        return 'SKIPPED'
    return 'PASSED'


def diagnostic(raw):
    text = str(raw.get('detail', ''))
    frames = [line for line in text.splitlines() if re.match(r'^(?:tests|runtime_protocol|astrid_runtime)/[^\n:]+\.py:\d+', line)]
    errors = [line[1:].strip() for line in text.splitlines() if line.startswith('E ')]
    # Request IDs are retained literally in per-ID data, but omitted only from
    # category grouping so the same HTTP refusal has one category label.
    grouped_errors = [re.sub(r"'request_id': '[0-9a-f]+'", "'request_id': '<recorded-per-ID>'", e) for e in errors]
    return {
        'frames': frames,
        'first_caller_frame': frames[0] if frames else None,
        'last_exception_frame': frames[-1] if frames else None,
        'error_lines': errors,
        'grouped_error_lines': grouped_errors,
        'detail_sha256': sha(text.encode()),
    }


def attrname(n):
    if isinstance(n, ast.Name):
        return n.id
    if isinstance(n, ast.Attribute):
        return attrname(n.value) + '.' + n.attr
    return ''


def ast_facts(data, filename):
    tree = ast.parse(data, filename=filename)
    nodes = list(ast.walk(tree))
    asserts = collections.Counter(ast.dump(n, include_attributes=False) for n in nodes if isinstance(n, ast.Assert))
    all_pytest = collections.Counter(ast.dump(n, include_attributes=False) for n in nodes if isinstance(n, ast.Call) and attrname(n.func).startswith('pytest.'))
    oracles = collections.Counter(ast.dump(n, include_attributes=False) for n in nodes if isinstance(n, ast.Call) and attrname(n.func) in {'pytest.raises', 'pytest.warns', 'pytest.fail', 'pytest.approx', 'pytest.deprecated_call'})
    signatures = [(n.name, ast.dump(n.args, include_attributes=False), [ast.dump(d, include_attributes=False) for d in n.decorator_list]) for n in nodes if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test_')]
    return {'assertions': asserts, 'all_pytest_calls': all_pytest, 'pytest_oracles': oracles, 'test_signatures': signatures}


def audit_preservation(invocation):
    declared = json.loads((LOCAL / 'assertion-preservation.json').read_text())
    changes = git('diff', '--name-status', BASE).decode().splitlines()
    product_changes = [line for line in changes if not line.split('\t')[-1].startswith('tests/')]
    assert product_changes == declared['product_changes'] == []
    original_paths = [p for p in git('ls-tree', '-r', '--name-only', BASE, 'tests').decode().splitlines() if p.endswith('.py')]
    facts = {}
    totals = collections.Counter()
    current_snapshot_mismatch = []
    for path in original_paths:
        before = git('show', f'{BASE}:{path}')
        after = (REPO / path).read_bytes()
        if sha(after) != invocation['source_files'][path]:
            current_snapshot_mismatch.append(path)
        a, b = ast_facts(before, path), ast_facts(after, path)
        row = {'base_sha256': sha(before), 'current_sha256': sha(after), 'bytes_unchanged': before == after}
        for k in ['assertions', 'all_pytest_calls', 'pytest_oracles']:
            row[k] = {
                'original': sum(a[k].values()), 'current': sum(b[k].values()),
                'removed_or_changed': sum((a[k] - b[k]).values()),
                'added': sum((b[k] - a[k]).values()),
            }
            for field, v in row[k].items():
                totals[k + ':' + field] += v
        row['test_signatures_and_decorators_unchanged'] = a['test_signatures'] == b['test_signatures']
        assert row['test_signatures_and_decorators_unchanged']
        assert all(row[k]['removed_or_changed'] == 0 for k in ['assertions', 'all_pytest_calls', 'pytest_oracles'])
        if path in declared['files']:
            d = declared['files'][path]
            assert d['base_sha256'] == row['base_sha256']
            assert d['current_sha256'] == row['current_sha256']
            assert d['original_assertions'] == row['assertions']['original']
            assert d['current_assertions'] == row['assertions']['current']
            assert d['removed_assertions'] == row['assertions']['removed_or_changed']
            assert d['added_assertions'] == row['assertions']['added']
            assert not d['changed_test_signatures']
            assert d['removed_pytest_oracles'] == row['pytest_oracles']['removed_or_changed'] == 0
        facts[path] = row
    assert not current_snapshot_mismatch
    assert {p for p, r in facts.items() if not r['bytes_unchanged']} == set(declared['files'])
    return {
        'base': BASE, 'candidate_head': invocation['head'],
        'candidate_committed_tree': invocation['tree'],
        'candidate_worktree_status_at_execution': invocation['status'],
        'identity_limit': 'Candidate includes the recorded worktree diff, not solely the committed HEAD tree.',
        'original_python_files': len(original_paths),
        'original_files_changed': len(declared['files']),
        'original_files_byte_identical': sum(r['bytes_unchanged'] for r in facts.values()),
        'original_test_source_snapshot_mismatches': current_snapshot_mismatch,
        'totals': dict(totals), 'files': facts, 'diff_name_status': changes,
        'product_changes': product_changes,
        'root_audit_sha256': sha((LOCAL / 'assertion-preservation.json').read_bytes()),
        'root_audit_verified': True,
        'scope_limit': 'AST counters and signatures are preservation facts, not an implementation review or evidence that every oracle was reached.',
    }


def main():
    original_roster = json.loads((ORIGINAL / 'original-roster.json').read_text())
    by_id = {x['nodeid']: x for x in original_roster['ids']}
    g2 = collections.defaultdict(list)
    for raw in gzip.decompress((ORIGINAL / 'original-native-events.jsonl.gz').read_bytes()).splitlines():
        e = json.loads(raw)
        g2[e['g2_job_id']].append(e)
    g2 = {j: phase_map(es) for j, es in g2.items()}
    hosted = json.loads((ORIGINAL / 'hosted-973-reference.json').read_text())['native_by_g2_job']
    all_records = []
    lanes = []
    residuals = []
    candidate_invocations = []
    for lane, jid in [('unit', 134906035312), ('nightly', 134820393924)]:
        bdir, cdir = LOCAL / f'base-{lane}', LOCAL / f'candidate-{lane}'
        assert (cdir / 'exit.txt').exists()
        invocation = json.loads((cdir / 'invocation.json').read_text())
        candidate_invocations.append(invocation)
        braw = [json.loads(x) for x in (bdir / 'events.jsonl').read_text().splitlines()]
        craw = [json.loads(x) for x in (cdir / 'events.jsonl').read_text().splitlines()]
        baseline = phase_map(e for e in braw if e.get('event') == 'test_report')
        reports = [e for e in craw if e.get('event') == 'test_report']
        candidate = phase_map(reports)
        finish = [e for e in craw if e['event'] == 'finish']
        exitcode = int((cdir / 'exit.txt').read_text())
        assert len(finish) == 1 and finish[0]['exitstatus'] == exitcode
        assert set(candidate) == set(baseline) == set(g2[jid]) == set(invocation['requested_nodeids'])
        assert finish[0]['collected'] == len(candidate)
        assert compare(g2[jid], baseline)['changed_native_ids'] == 0
        transitions = collections.Counter()
        counts = collections.Counter()
        phases = collections.Counter()
        for nodeid in sorted(candidate):
            a, b = outcome(baseline[nodeid]), outcome(candidate[nodeid])
            transitions[a + '->' + b] += 1
            counts[b] += 1
            for phase, e in candidate[nodeid].items():
                phases[phase + ':' + e['outcome']] += 1
            r = {
                'nodeid': nodeid, 'group': by_id[nodeid]['group'], 'lane': lane,
                'g2_outcome': outcome(g2[jid][nodeid]), 'base_outcome': a,
                'candidate_outcome': b, 'transition': a + '->' + b,
                'g2_phases': g2[jid][nodeid], 'base_phases': baseline[nodeid],
                'candidate_phases': candidate[nodeid],
            }
            all_records.append(r)
        for e in reports:
            if e['outcome'] == 'failed':
                residuals.append({'nodeid': e['nodeid'], 'group': by_id[e['nodeid']]['group'], 'lane': lane, 'phase': e['when'], 'base_phase_outcome': baseline[e['nodeid']].get(e['when'], {}).get('outcome', 'not-executed'), **diagnostic(e)})
        lanes.append({
            'lane': lane, 'native_ids': len(candidate), 'missing': [], 'extra': [],
            'candidate_head': invocation['head'], 'candidate_committed_tree': invocation['tree'],
            'worktree_status': invocation['status'],
            'agent_pin': invocation['agent_pin'], 'worker_environment': invocation['worker_environment'],
            'native_exit': exitcode, 'native_finish': finish[0],
            'outcomes': dict(counts), 'phase_outcomes': dict(phases), 'transitions': dict(transitions),
            'source_files_snapshot_sha256': sha(json.dumps(invocation['source_files'], sort_keys=True).encode()),
            'original_receipts': {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in [cdir / 'invocation.json', cdir / 'events.jsonl', cdir / 'native.xml', cdir / 'terminal.log', cdir / 'exit.txt']},
        })
    assert len(all_records) == len({x['nodeid'] for x in all_records}) == 366
    assert candidate_invocations[0]['source_files'] == candidate_invocations[1]['source_files']
    preservation = audit_preservation(candidate_invocations[0])
    dump(LOCAL / 'candidate-assertion-audit.json', preservation)

    grouped = collections.defaultdict(list)
    for r in residuals:
        grouped[(r['lane'], r['phase'], r['last_exception_frame'], tuple(r['grouped_error_lines']))].append(r)
    categories = [{'lane': lane, 'phase': phase, 'exception_site': site, 'error_lines': list(errors), 'count': len(rs), 'nodes': [r['nodeid'] for r in rs], 'representative_frames': rs[0]['frames']} for (lane, phase, site, errors), rs in grouped.items()]
    summary = {
        'status': 'Completed local candidate observations; remaining failures preserved, no verdict',
        'distinct_original_ids': len(all_records),
        'candidate_outcomes': dict(collections.Counter(r['candidate_outcome'] for r in all_records)),
        'transitions': dict(collections.Counter(r['transition'] for r in all_records)),
        'by_original_group': {g: dict(collections.Counter(r['candidate_outcome'] for r in all_records if r['group'] == g)) for g in sorted({r['group'] for r in all_records})},
        'lanes': lanes, 'residual_categories': categories,
        'assertion_preservation': {k: v for k, v in preservation.items() if k != 'files'},
        'limitations': [
            'Candidate has committed head c0cf8bfd plus recorded worktree edits; outputs are not execution of the clean c0 tree alone.',
            'Local CPython3.13.5 Linux observations do not replace hosted3.11, macOS or seccomp qualification.',
            '52 setup errors leave 52 original calls unexecuted. Two original setup errors now reach a failing call; they are not repaired IDs.',
            'The two source files retaining 51 neutral parameters are unchanged; no neutral-to-authoring substitution was made.',
            'Traceback and source facts identify reached boundaries; they do not establish an introducing change or decide product defect versus fixture repair.',
        ],
    }
    dump(LOCAL / 'candidate-outcome-summary.json', summary)
    dump(LOCAL / 'candidate-per-id-comparison.json', {'summary': summary, 'ids': all_records, 'residuals': residuals})
    compact = [{k: r[k] for k in ['nodeid', 'group', 'lane', 'g2_outcome', 'base_outcome', 'candidate_outcome', 'transition']} | {'candidate_phases': {p: e['outcome'] for p, e in r['candidate_phases'].items()}} for r in all_records]
    dump(LOCAL / 'candidate-compact-roster.json', compact)
    (LOCAL / 'candidate-residual-ids.txt').write_text('\n'.join(sorted(r['nodeid'] for r in all_records if r['candidate_outcome'] != 'PASSED')) + '\n')
    print(json.dumps({'outcomes': summary['candidate_outcomes'], 'transitions': summary['transitions'], 'groups': summary['by_original_group'], 'original_python_files': preservation['original_python_files'], 'changed_original_files': preservation['original_files_changed'], 'preservation_totals': preservation['totals'], 'residual_categories': [{k: v for k, v in c.items() if k not in ['nodes', 'representative_frames']} for c in categories]}, indent=2))


if __name__ == '__main__':
    main()
